# Nine Men's Morris - Launch Instructions

Welcome to Nine Men's Morris! This game requires a full Java 17 installation to run successfully. It's been tested on macOS Ventura 13.3.1 with aarch64 Java 17.0.4 and Windows 11 x64 Java 17.0.1. Please note that this game is known not to work with Java 15 and below.

## Checking Your Java Version

Before proceeding, ensure you have the correct Java version installed. To do this, open your terminal (Command Prompt on Windows, Terminal on macOS), and type:

```zsh
java --version
```

The output should indicate that you are running Java 17. If not, you'll need to download and install Java 17.

## Prerequisites for the Game

In addition to Java 17, you'll need the correct version of the JavaFX SDK. Here's how to get it:

1. Visit [GluonHQ](https://gluonhq.com/products/javafx/) to download the JavaFX SDK.

2. Make the following selections:
   - JavaFX version: 20.0.1
   - Operating System: Matches your machine
   - Architecture: Matches your machine
   - Type: SDK

3. Download the SDK and extract the zip file *here*.

## Directory Structure

After extracting the SDK, your directory structure should be:

```zsh
.
├── README.md
├── javafx-sdk-20.0.1
│   ├── legal
│   ├── lib
│   └── src.zip
└── nine-mens-morris.jar
```

## Launching the Game

To launch the game, navigate to this directory and execute the following command:

```zsh
java \
--module-path ./javafx-sdk-20.0.1/lib \
--add-modules javafx.controls,javafx.fxml \
-jar ./nine-mens-morris.jar
```

Adapt the command to your system configuration.

This command specifies the JavaFX libraries' path and links them to the game. The game will launch upon successful execution.

Enjoy the game!
